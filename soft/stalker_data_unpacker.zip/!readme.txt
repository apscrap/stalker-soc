Note: Use PROPER version of the tool for your game:
STALKER_Data_Unpacker_EN.exe - for English release (THQ)
STALKER_Data_Unpacker_RU.exe - for Russian release (GSC/1C)

You can use this tool from command-line as well:
STALKER_Data_Unpacker_EN.exe <gamedata.db?> [output-directory]
STALKER_Data_Unpacker_RU.exe <gamedata.db?> [output-directory]                                                                                                                                       Downloaded from AG.ru
